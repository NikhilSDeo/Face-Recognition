﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FaceCap
{
    public partial class Test_Window : Form
    {
        public Test_Window()
        {
            InitializeComponent();
        }
    }
}
